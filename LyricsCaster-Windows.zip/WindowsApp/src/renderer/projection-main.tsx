import React from 'react';
import ReactDOM from 'react-dom/client';
import ProjectionWindow from './projection/ProjectionWindow';

const container = document.getElementById('root');
if (!container) {
  throw new Error('Failed to find the root element');
}

const root = ReactDOM.createRoot(container);
root.render(
  <React.StrictMode>
    <ProjectionWindow />
  </React.StrictMode>
);
